Kyoto Free Translation Task

All data is distributed under the Creative Commons License ver. 3.0.
http://creativecommons.org/licenses/by-sa/3.0/

More details and instructions on how to use this package can be found on the task web site: http://www.phontron.com/kftt
